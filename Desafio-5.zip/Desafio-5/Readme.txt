Con respecto a cual de los motores elijiría, creo que con la mínima experiencia que tengo, me inclinaría por EJS.
Me parece el que se ajusta mas a el html puro y es facil de insertar Javascript, creo que con un poco mas de estudio
podría sacarle mucho provecho.
